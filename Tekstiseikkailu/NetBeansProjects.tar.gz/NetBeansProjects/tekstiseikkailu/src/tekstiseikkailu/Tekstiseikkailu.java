/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tekstiseikkailu;

import java.util.Scanner;

/**
 *
 * @author guest-fjtquv
 */
public class Tekstiseikkailu {
//haista *****

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner lukija = new Scanner(System.in);
        System.out.println("Kerro nimesi.");
        String nimi = (lukija.nextLine());
        System.out.println("anna ikäsi.");
        int ika = Integer.parseInt(lukija.nextLine());
        System.out.println("Tervehdys sinulle " + nimi + ". " + ika + " on hyva olla.");
        System.out.println("Kello käy jo " + 2 + 2 + ",");
        System.out.println("Ja polkuja haarautuu tästä " + (1 + 2) + ".");
        System.out.println("Käytkö polulle 1,2 vai 3?");
        int valinta = Integer.parseInt(lukija.nextLine());

        if (valinta == 1) {
            System.out.println("Sankarin niin urhean, \nsöi kuitenkin lopulta hirviö.");
        } else if (valinta == 2) {
            System.out.println("Haha kuolit jollekki nyypälle");
        } else {
            System.out.println("Ja näin kannatti koittaa, \noli linnan ovi auki.");
            System.out.println("Näkyi ovella portaat ja sali, \nkumman valitsee sankari?");
            String kohde = lukija.nextLine();
            if (kohde.equals("sali")) {
                System.out.println("Kuului kauhea karjaisu, \npelästytti pois sankarin.");
            } else {
                System.out.println("Askelmat jyrkät, \nselvisi täpärästi " + nimi);
            
            System.out.println("Torni kun paljastui tyhjäksi, \njatkoiko sankari ullakon vai parvekkeen?");
            String ammuja = lukija.nextLine();
            if (ammuja.equals("parvekkeen")) {
                System.out.println("Jäi sankarin seikkailu vailla palkkiota, \noli linna jo tyhjä.");
            } else {
                System.out.println("Ullakon pölyisestä nurkasta, \nlöysi sankari lopulta prinsessan.");
            }
            }
        }
    }
}
